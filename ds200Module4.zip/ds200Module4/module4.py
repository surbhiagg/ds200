import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


def abbreviate(strList):
    abbrList = []
    for i in range(len(strList)):
        word = strList[i]
        abbrLen = min(4, len(word))
        abbrList.append(word[0:abbrLen])
    return abbrList

def getData(fileName, newColumnNames, rowsToSkip, index_col):
    df=pd.read_csv(fileName, header=0, index_col=index_col, skiprows = rowsToSkip)
    colLabels = df.columns
    df.columns = newColumnNames
    return df, colLabels


def configForEducationDataset():
    config = {}
    config['fileName'] = './data.csv'
    config['requiredColumnIndices'] = [1,2,3,4,5,6,7]
    config['newColumnNames'] = ['state', 'boysIn9th', 'girlsIn9th', 'totalIn9th', 'boysIn10th', 'girlsIn10th', 'totalIn10th', 'boys9to10', 'girls9to10', 'total9to10', 'boys1to10', 'girls1to10', 'total1to10']
    config['rowsToSkip'] = [36] # Skip row containing total stats    
    config['index_col'] = [0] # S.No column is indexed
    config['pairsToPlot'] = [[1,4],[2,5],[3,6],[1,2],[4,5], [7,8],[10,11]]
    config['boxPlotPairsToPlot'] = [[1,4],[2,5],[3,6],[1,2],[4,5], [7,8]]
    config['plotDirectory'] = './plots/'
    return config

def plotSingleBarPlot(columnName, df, xTickLabelsList, xLabel, columnLabel, plotsDirectory):
    plt.figure(figsize=(18,7))
    numberOfDataPoints = df.shape[0]
    positionOfBars = np.arange(1, numberOfDataPoints+1)
    #plot bar plot with xticks which is position of bars as first argument and height of bars as second argument
    plt.bar(positionOfBars, df[columnName], label = columnLabel)
    plt.xticks(positionOfBars, xTickLabelsList, rotation=45) #specify labels on xticks
    plt.xlabel(xLabel)
    plt.ylabel(columnLabel)
    plt.legend() #enabling legend
    name = plotsDirectory+ 'bar_'+columnName + '.png'
    plt.savefig(name)
    plt.close()

def plotGroupOf2BarPlots(pair, df, xTickLabelsList, xLabel, colLabelList, plotsDirectory):
    plt.figure(figsize=(18,7))
    width=1
    #plotting first type of bars
    numberOfDataPoints = df.shape[0]
    positionOfBars = np.arange(0, numberOfDataPoints*3, 3)
    col1 = df.columns[pair[0]]
    col2 = df.columns[pair[1]]
    col1Label = colLabelList[pair[0]]
    col2Label = colLabelList[pair[1]]
    plt.bar(positionOfBars,df[col1],width,color='#ddbbaa',label=col1Label)
    plt.bar([x+width for x in positionOfBars],df[col2],width,color='#ddffaa',label=col2Label)
    plt.xticks(positionOfBars, xTickLabelsList, rotation=45)
    plt.xlabel(xLabel)
    plt.ylabel(col1Label + ' and ' + col2Label)    
    plt.legend()
    name = plotsDirectory+ 'doublebar_'+ col1 + '_' + col2 + '.png'
    plt.savefig(name)
    plt.close()


def plotScatterPlot(pair, df, colLabelList, plotsDirectory, legendLabel):
    plt.figure(figsize=(15,10))
    col1 = df.columns[pair[0]]
    col2 = df.columns[pair[1]]
    col1Label = colLabelList[pair[0]]
    col2Label = colLabelList[pair[1]]
    plt.scatter(df[col1],df[col2], label=legendLabel)
    lineCoordinate = max(max(df[col1]), max(df[col2]))
    plt.plot([0,lineCoordinate], [0,lineCoordinate], '--')
    plt.legend()
    plt.xlabel(col1Label)
    plt.ylabel(col2Label)    
    name = plotsDirectory+ 'scatter_'+ col1 + '_' + col2 + '.png'
    plt.savefig(name)
    plt.close()

def plotBoxPlot(columnList, df, colLabelList, plotsDirectory): 
    plt.figure(figsize=(8,8))
    plotMap=[]
    xLabels = []
    #create a list of lists where each list will have a corresponding box plot
    for colNumber in columnList:
        colName = df.columns[colNumber]
        plotMap.append(df[colName].dropna().tolist())
        xLabels.append(colName)
    #plotting
    plt.boxplot(plotMap)
    #specifying labels
    xTickList = np.arange(1, len(columnList)+1)
    plt.xticks(xTickList,xLabels)
    plt.xlabel(" ")
    plt.ylabel("No of students")
    plt.legend()
    name = plotsDirectory+ 'boxPlot_'+ "_".join(xLabels)+ '.png'
    plt.savefig(name)
    plt.close()

config = configForEducationDataset()
requiredColumnIndices =  config['requiredColumnIndices']
pairs = config['pairsToPlot']
boxPlotPairs = config['boxPlotPairsToPlot']
plotsDirectory  = config['plotDirectory']

toPlotSingleBar = True
toPlotDoubleBar = True
toPlotScatter = True
toPlotBox  = True

df, initialColLabels =  getData(config['fileName'], config['newColumnNames'], config['rowsToSkip'], config['index_col'])
stateList = list(df['state'])   

if toPlotSingleBar:
    for columnNumber in requiredColumnIndices:
        columnName = df.columns[columnNumber]
        columnLabel = initialColLabels[columnNumber]
        xTickLabelsList =  abbreviate(stateList)
        xLabel = "State"
        plotSingleBarPlot(columnName, df, xTickLabelsList, xLabel, columnLabel, plotsDirectory)
    

if toPlotDoubleBar:
    for pairNum in range(len(pairs)):
        xTickLabelsList =  abbreviate(stateList)
        xLabel = "State"
        plotGroupOf2BarPlots(pairs[pairNum], df, xTickLabelsList, xLabel, initialColLabels, plotsDirectory)    
    
if toPlotScatter:
    for pairNum in range(len(pairs)):
            plotScatterPlot(pairs[pairNum], df, initialColLabels, plotsDirectory, "State wise enrollment")
        
if toPlotBox:    
    for pairNum in range(len(boxPlotPairs)):
        plotBoxPlot( boxPlotPairs[pairNum], df, initialColLabels, plotsDirectory)
        